import {DeliveryPerson} from "./deliveryPerson.model.js"
import {ProofOfDelivery} from "./proofOfDelivery.model.js"

export {
    DeliveryPerson,
    ProofOfDelivery
}

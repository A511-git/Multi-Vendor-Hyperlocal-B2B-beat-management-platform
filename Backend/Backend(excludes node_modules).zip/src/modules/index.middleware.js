import {} from './admin/middleware/index.js'
import {} from './customer/middleware/index.js'
import {} from './deliveryPerson/middleware/index.js'
import {} from './fieldMan/middleware/index.js'
import {} from './order/middleware/index.js'
import {} from './product/middleware/index.js'
import {} from './vendor/middleware/index.js'
import {} from './user/middleware/index.js'


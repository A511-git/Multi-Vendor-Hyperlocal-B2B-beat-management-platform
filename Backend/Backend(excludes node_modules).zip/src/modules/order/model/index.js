import {Order} from "./order.model.js"
import {OrderProduct} from "./orderProduct.model.js"



export {
    Order,
    OrderProduct
}

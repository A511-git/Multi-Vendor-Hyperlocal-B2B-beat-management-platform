import {Admin} from "./admin.model.js"


export {
    Admin
}